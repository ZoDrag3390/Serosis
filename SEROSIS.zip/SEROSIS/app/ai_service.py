from datetime import datetime
from .weather_service import weather_service

class AIService:
    def __init__(self):
        self.field_width = 5
        self.field_height = 5
        
    def generate_field_map(self, sensors_data, crop_requirements):
        """Generate virtual field map using inverse distance weighting"""
        field_map = []
        
        for y in range(self.field_height):
            row = []
            for x in range(self.field_height):
                predicted_moisture = self._predict_moisture_at(x, y, sensors_data)
                row.append(int(predicted_moisture))
            field_map.append(row)
        
        return field_map
    
    def _predict_moisture_at(self, target_x, target_y, sensors_data):
        """Predict moisture at a location using distance-weighted average"""
        total_weight = 0
        weighted_sum = 0
        
        for sensor_id, sensor_data in sensors_data.items():
            if 'location' not in sensor_data:
                continue
                
            sensor_x = sensor_data['location']['x']
            sensor_y = sensor_data['location']['y']
            
            # Calculate Euclidean distance (no numpy needed)
            distance = ((sensor_x - target_x) ** 2 + (sensor_y - target_y) ** 2) ** 0.5
            
            # Avoid division by zero
            if distance == 0:
                return sensor_data['moisture']
            
            # Weight = 1/distance² (closer points have more influence)
            weight = 1 / (distance ** 2)
            weighted_sum += sensor_data['moisture'] * weight
            total_weight += weight
        
        # If no sensors, return default value
        if total_weight == 0:
            return 50
            
        return weighted_sum / total_weight
    
    def generate_recommendations(self, field_map, sensors_data, crop_info):
        """Generate AI recommendations with weather intelligence"""
        recommendations = []
        
        # Get weather forecast
        weather_data = weather_service.get_weather_forecast()
        
        # Flatten the field map to analyze
        all_values = []
        for row in field_map:
            all_values.extend(row)
            
        avg_moisture = sum(all_values) / len(all_values)
        
        # Count areas outside optimal range
        dry_areas = sum(1 for value in all_values if value < crop_info['optimal_moisture']['min'])
        wet_areas = sum(1 for value in all_values if value > crop_info['optimal_moisture']['max'])
        optimal_areas = sum(1 for value in all_values if crop_info['optimal_moisture']['min'] <= value <= crop_info['optimal_moisture']['max'])
        
        # Crop-specific recommendations
        crop_name = crop_info['name']
        
        # WEATHER-INTELLIGENT RECOMMENDATIONS
        current_temp = weather_data['current']['temperature']
        rain_prob_today = weather_data['forecast'][0]['rain_probability']
        rain_prob_tomorrow = weather_data['forecast'][1]['rain_probability']
        heavy_rain_tomorrow = 'heavy' in weather_data['forecast'][1]['description'].lower()
        
        # Irrigation recommendations with weather consideration
        if dry_areas > 3:
            if rain_prob_tomorrow > 50:
                recommendations.append(f"🌧️ {dry_areas} dry areas - but {rain_prob_tomorrow}% rain expected tomorrow, wait for natural irrigation")
            else:
                recommendations.append(f"🚨 {dry_areas} dry areas detected - {crop_name} needs irrigation today")
        elif dry_areas > 0:
            recommendations.append(f"⚠️ {dry_areas} slightly dry areas - monitor {crop_name} closely")
        
        # Weather-based warnings
        if heavy_rain_tomorrow and avg_moisture > 50:
            recommendations.append(f"⛈️ Heavy rain forecast tomorrow - reduce irrigation to prevent waterlogging")
        
        if rain_prob_today > 70 and wet_areas > 2:
            recommendations.append(f"💧 Rain expected today - already {wet_areas} overwatered areas")
        
        if wet_areas > 3:
            recommendations.append(f"💧 {wet_areas} overwatered areas - reduce irrigation")
        
        # Temperature-based recommendations
        if current_temp > 35:
            if crop_name.lower() in ['wheat', 'leafy vegetables', 'lettuce']:
                recommendations.append("🌡️ High temperature warning - increase watering frequency for heat-sensitive crops")
            elif crop_name.lower() in ['cotton', 'millets']:
                recommendations.append("🌡️ High temperature - drought-resistant crops handling well")
                
        elif current_temp < 15:
            if crop_name.lower() in ['rice', 'tea', 'tropical crops']:
                recommendations.append("❄️ Low temperature alert - monitor tropical crops for cold stress")
            elif crop_name.lower() in ['wheat', 'barley']:
                recommendations.append("❄️ Cool temperature - ideal for winter crops")
        
        # Crop-specific weather advice
        if crop_name.lower() == 'rice' and rain_prob_tomorrow < 30 and avg_moisture < 70:
            recommendations.append("💦 Rice needs consistent moisture - irrigate to maintain high levels")
            
        if crop_name.lower() == 'millets' and rain_prob_tomorrow > 60 and avg_moisture > 40:
            recommendations.append("🌵 Millets prefer drier conditions - reduce watering before expected rain")
        
        # Optimal conditions celebration
        if optimal_areas >= len(all_values) * 0.8:  # 80% optimal
            recommendations.append(f"✅ {crop_name} field conditions are excellent!")
        
        # Sensor health check
        active_sensors = len(sensors_data)
        if active_sensors < 2:
            recommendations.append("🔧 Consider adding more sensors for better field coverage")
        
        # Add weather alerts from weather service
        recommendations.extend(weather_data.get('alerts', []))
        
        # Fallback if no specific recommendations
        if not recommendations:
            if rain_prob_tomorrow > 60:
                recommendations.append("🌧️ Rain expected tomorrow - adjust irrigation accordingly")
            else:
                recommendations.append("🌱 Field conditions stable - continue current practices")
        
        return recommendations
    
    def get_field_health_score(self, field_map, crop_info):
        """Calculate overall field health score (0-100)"""
        all_values = []
        for row in field_map:
            all_values.extend(row)
            
        optimal_min = crop_info['optimal_moisture']['min']
        optimal_max = crop_info['optimal_moisture']['max']
        
        optimal_count = 0
        for value in all_values:
            if optimal_min <= value <= optimal_max:
                optimal_count += 1
        
        health_score = (optimal_count / len(all_values)) * 100
        return int(health_score)

# Global instance
ai_service = AIService()