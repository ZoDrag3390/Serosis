# Crop database with optimal ranges
CROP_DATABASE = {
    "wheat": {
        "name": "Wheat",
        "optimal_moisture": {"min": 50, "max": 70},
        "optimal_temperature": {"min": 15, "max": 25},
        "optimal_humidity": {"min": 40, "max": 60},
        "growth_period": "90-120 days",
        "water_requirement": "Medium",
        "season": "Winter (Rabi)"
    },
    "rice": {
        "name": "Rice",
        "optimal_moisture": {"min": 70, "max": 90},
        "optimal_temperature": {"min": 20, "max": 35},
        "optimal_humidity": {"min": 60, "max": 80},
        "growth_period": "100-150 days",
        "water_requirement": "High",
        "season": "Monsoon (Kharif)"
    },
    "coffee": {
        "name": "Coffee",
        "optimal_moisture": {"min": 60, "max": 80},
        "optimal_temperature": {"min": 15, "max": 28},
        "optimal_humidity": {"min": 60, "max": 80},
        "growth_period": "3-4 years to first harvest",
        "water_requirement": "Medium-High",
        "season": "Perennial"
    },
    "millets": {
        "name": "Millets",
        "optimal_moisture": {"min": 30, "max": 50},
        "optimal_temperature": {"min": 20, "max": 35},
        "optimal_humidity": {"min": 30, "max": 50},
        "growth_period": "60-90 days",
        "water_requirement": "Low",
        "season": "Summer"
    },
    "jute": {
        "name": "Jute",
        "optimal_moisture": {"min": 60, "max": 80},
        "optimal_temperature": {"min": 24, "max": 37},
        "optimal_humidity": {"min": 60, "max": 90},
        "growth_period": "120-150 days",
        "water_requirement": "High",
        "season": "Monsoon"
    },
    "tea": {
        "name": "Tea",
        "optimal_moisture": {"min": 70, "max": 90},
        "optimal_temperature": {"min": 15, "max": 30},
        "optimal_humidity": {"min": 70, "max": 90},
        "growth_period": "3 years to first harvest",
        "water_requirement": "High",
        "season": "Perennial"
    },
    "corn": {
        "name": "Corn (Maize)",
        "optimal_moisture": {"min": 50, "max": 70},
        "optimal_temperature": {"min": 18, "max": 32},
        "optimal_humidity": {"min": 50, "max": 70},
        "growth_period": "80-110 days",
        "water_requirement": "Medium",
        "season": "Kharif/Summer"
    },
    "cotton": {
        "name": "Cotton",
        "optimal_moisture": {"min": 40, "max": 60},
        "optimal_temperature": {"min": 21, "max": 35},
        "optimal_humidity": {"min": 40, "max": 60},
        "growth_period": "150-180 days",
        "water_requirement": "Medium",
        "season": "Kharif"
    }
}

# Default crop (can be changed by user)
DEFAULT_CROP = "wheat"