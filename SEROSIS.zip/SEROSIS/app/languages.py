# English translations
ENGLISH = {
    "dashboard_title": "SEROSIS Dashboard",
    "welcome": "WELCOME TO",
    "monitoring_for": "Monitoring for",
    "change_crop": "Change Crop",
    "field_sensors": "Field Sensors",
    "active": "active",
    "moisture": "MOISTURE",
    "soil_temperature": "SOIL TEMPERATURE", 
    "humidity": "HUMIDITY",
    "about": "About",
    "contact": "Contact",
    "guide": "Guide",
    "analytics": "Analytics",
    "select_crop": "Select Crop",
    "choose_crop": "Choose your crop to get customized monitoring",
    "water": "Water",
    "season": "Season",
    "optimal_range": "Optimal Range",
    "selected": "SELECTED",
    "ai_predictions": "AI Predictions",
    "field_health_score": "Field Health Score",
    "ai_field_map": "AI Field Moisture Map",
    "sensors": "Sensors",
    "last_updated": "Last updated",
    "ai_recommendations": "AI Recommendations",
    "moisture_trend": "Moisture Trend",
    "temperature_trend": "Temperature Trend",
    "humidity_trend": "Humidity Trend",
    "dry": "Dry",
    "low": "Low", 
    "optimal": "Optimal",
    "high": "High",
    "back": "Back",
    "loading": "Loading...",
    "no_sensors": "No sensors connected",
    "failed_load": "Failed to load sensors",
    
    # Status messages
    "optimal_status": "OPTIMAL",
    "good_status": "GOOD", 
    "low_status": "LOW",
    "high_status": "HIGH",
    "cold_status": "COLD",
    "hot_status": "HOT",
    "danger_status": "DANGER",
    
    # AI Predictions
    "yield_prediction": "🌾 AI Yield Prediction",
    "tons_hectare": "tons/hectare",
    "average": "Average",
    "trend": "Trend",
    "confidence": "Confidence",
    "harvest_readiness": "📅 Harvest Readiness",
    "optimal_harvest": "Optimal Harvest",
    "days_remaining": "Days Remaining",
    "status": "Status",
    
    # Weather
    "partly_cloudy": "Partly Cloudy",
    "rain_expected": "Rain Expected",
    "heavy_rain": "Heavy Rain"
}

# Hindi translations
HINDI = {
    "dashboard_title": "SEROSIS डैशबोर्ड",
    "welcome": "आपका स्वागत है",
    "monitoring_for": "निगरानी के लिए",
    "change_crop": "फसल बदलें",
    "field_sensors": "खेत सेंसर",
    "active": "सक्रिय",
    "moisture": "नमी",
    "soil_temperature": "मिट्टी का तापमान",
    "humidity": "आर्द्रता",
    "about": "हमारे बारे में",
    "contact": "संपर्क करें",
    "guide": "मार्गदर्शिका",
    "analytics": "विश्लेषण",
    "select_crop": "फसल चुनें",
    "choose_crop": "अनुकूलित निगरानी के लिए अपनी फसल चुनें",
    "water": "पानी",
    "season": "मौसम",
    "optimal_range": "इष्टतम सीमा",
    "selected": "चयनित",
    "ai_predictions": "AI भविष्यवाणियाँ",
    "field_health_score": "खेत स्वास्थ्य स्कोर",
    "ai_field_map": "AI खेत नमी मानचित्र",
    "sensors": "सेंसर",
    "last_updated": "अंतिम अपडेट",
    "ai_recommendations": "AI सिफारिशें",
    "moisture_trend": "नमी रुझान",
    "temperature_trend": "तापमान रुझान", 
    "humidity_trend": "आर्द्रता रुझान",
    "dry": "सूखा",
    "low": "कम",
    "optimal": "इष्टतम",
    "high": "उच्च",
    "back": "वापस",
    "loading": "लोड हो रहा है...",
    "no_sensors": "कोई सेंसर जुड़े नहीं हैं",
    "failed_load": "सेंसर लोड करने में विफल",
    
    # Status messages
    "optimal_status": "इष्टतम",
    "good_status": "अच्छा",
    "low_status": "कम", 
    "high_status": "उच्च",
    "cold_status": "ठंडा",
    "hot_status": "गर्म",
    "danger_status": "खतरा",
    
    # AI Predictions
    "yield_prediction": "🌾 AI उपज भविष्यवाणी",
    "tons_hectare": "टन/हेक्टेयर",
    "average": "औसत",
    "trend": "रुझान",
    "confidence": "विश्वास",
    "harvest_readiness": "📅 फसल तत्परता",
    "optimal_harvest": "इष्टतम कटाई",
    "days_remaining": "शेष दिन",
    "status": "स्थिति",
    
    # Weather
    "partly_cloudy": "आंशिक रूप से बादल",
    "rain_expected": "बारिश की संभावना",
    "heavy_rain": "भारी बारिश"
}

# Available languages
LANGUAGES = {
    'en': {'name': 'English', 'data': ENGLISH},
    'hi': {'name': 'हिन्दी', 'data': HINDI}
}

DEFAULT_LANGUAGE = 'en'