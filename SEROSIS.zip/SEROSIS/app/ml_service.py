import random
from datetime import datetime, timedelta
import pytz
import math 

class MLService:
    def __init__(self):
        # Simple linear regression coefficients (pretend they were trained on real data)
        self.yield_coefficients = {
            'wheat': {'moisture': 0.8, 'temperature': 0.6, 'health_score': 1.2, 'base': 2.5},
            'rice': {'moisture': 1.1, 'temperature': 0.4, 'health_score': 1.5, 'base': 3.2},
            'corn': {'moisture': 0.7, 'temperature': 0.8, 'health_score': 1.1, 'base': 4.0},
            'millets': {'moisture': 0.4, 'temperature': 0.9, 'health_score': 0.8, 'base': 1.8},
            'cotton': {'moisture': 0.6, 'temperature': 0.7, 'health_score': 1.0, 'base': 2.2}
        }
        
        # Historical yield data for comparison (tons/hectare)
        self.average_yields = {
            'wheat': 3.2, 'rice': 4.1, 'corn': 3.8, 'millets': 1.5, 'cotton': 2.1,
            'coffee': 0.8, 'tea': 1.2, 'jute': 2.4
        }
    
    def _random_normal(self, mean=0, std_dev=0.2):
        """Simple random normal distribution without numpy"""
        # Box-Muller transform simplified
        u1 = 1.0 - random.random()
        u2 = 1.0 - random.random()
        z0 = math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)
        return z0 * std_dev + mean
    
    def predict_yield(self, crop_type, field_health_score, avg_moisture, avg_temperature, days_to_harvest=30):
        """Predict crop yield using simple linear regression"""
        
        if crop_type not in self.yield_coefficients:
            # Default prediction for unknown crops
            base_yield = self.average_yields.get(crop_type, 2.5)
            return {
                'predicted_yield': base_yield,
                'confidence': 'medium',
                'message': f'Based on regional averages: {base_yield} tons/hectare'
            }
        
        coeff = self.yield_coefficients[crop_type]
        
        # Simple linear regression: yield = base + coeff1*moisture + coeff2*temp + coeff3*health
        predicted = (
            coeff['base'] +
            coeff['moisture'] * (avg_moisture / 100) * 2 +
            coeff['temperature'] * (avg_temperature / 30) +
            coeff['health_score'] * (field_health_score / 100)
        )
        
        # Add some randomness for realism (using simple random instead of normal)
        predicted += random.uniform(-0.2, 0.2)
        predicted = max(predicted, 0.5)  # Minimum yield
        
        # Compare with average
        avg_yield = self.average_yields.get(crop_type, 2.5)
        difference = predicted - avg_yield
        percentage_change = (difference / avg_yield) * 100
        
        # Determine confidence and message
        if abs(percentage_change) > 20:
            confidence = 'high'
        elif abs(percentage_change) > 10:
            confidence = 'medium'
        else:
            confidence = 'low'
        
        if percentage_change > 10:
            trend = '📈 significantly above'
            recommendation = 'Excellent conditions! Maintain current practices.'
        elif percentage_change > 5:
            trend = '📈 above'
            recommendation = 'Good conditions. Continue monitoring.'
        elif percentage_change > -5:
            trend = '➡️ similar to'
            recommendation = 'Average conditions. Consider soil enrichment.'
        elif percentage_change > -10:
            trend = '📉 below'
            recommendation = 'Below average. Check for pests/diseases.'
        else:
            trend = '📉 significantly below'
            recommendation = 'Poor conditions. Immediate intervention needed.'
        
        return {
            'predicted_yield': round(predicted, 2),
            'average_yield': avg_yield,
            'difference_percentage': round(percentage_change, 1),
            'trend': trend,
            'confidence': confidence,
            'days_to_harvest': days_to_harvest,
            'recommendation': recommendation,
            'prediction_date': datetime.now(pytz.timezone('Asia/Kolkata')).isoformat()
        }
    
    def predict_harvest_readiness(self, crop_type, planting_date):
        """Predict optimal harvest date based on crop growth cycle"""
        growth_cycles = {
            'wheat': 120,  # days
            'rice': 150,
            'corn': 110,
            'millets': 90,
            'cotton': 180,
            'coffee': 365,  # per year
            'tea': 365
        }
        
        cycle_days = growth_cycles.get(crop_type, 120)
        
        # Handle both string and datetime planting_date
        if isinstance(planting_date, str):
            planting_date = datetime.fromisoformat(planting_date.replace('Z', '+00:00'))
        
        harvest_date = planting_date + timedelta(days=cycle_days)
        
        days_remaining = (harvest_date - datetime.now(pytz.timezone('Asia/Kolkata'))).days
        
        if days_remaining > 30:
            status = 'early_growth'
            message = f'Crop in early growth stage. {days_remaining} days until harvest.'
        elif days_remaining > 7:
            status = 'maturing'
            message = f'Crop maturing well. {days_remaining} days until optimal harvest.'
        elif days_remaining > 0:
            status = 'ready_soon'
            message = f'Harvest approaching! {days_remaining} days until ready.'
        else:
            status = 'ready'
            message = 'Crop ready for harvest!'
        
        return {
            'optimal_harvest_date': harvest_date.strftime('%Y-%m-%d'),
            'days_remaining': max(days_remaining, 0),
            'status': status,
            'message': message
        }

# Global instance
ml_service = MLService()