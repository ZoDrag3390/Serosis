from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
import os
import json
from datetime import datetime, timezone, timedelta
import pytz
from .crop_data import CROP_DATABASE, DEFAULT_CROP
from .ai_service import ai_service
from .weather_service import weather_service
import asyncio
from .ml_service import ml_service
from .languages import LANGUAGES, DEFAULT_LANGUAGE

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BASE_DIR)
TEMPLATE_DIR = os.path.join(ROOT_DIR, "templates")

templates = Jinja2Templates(directory=TEMPLATE_DIR)
router = APIRouter()

# WebSocket manager
manager = None

def set_manager(ws_manager):
    global manager
    manager = ws_manager

def get_ist_time():
    """Get current Indian Standard Time"""
    ist = pytz.timezone('Asia/Kolkata')
    return datetime.now(ist)

async def broadcast_sensor_update():
    """Broadcast sensor data to all connected WebSocket clients"""
    if manager is None:
        return
        
    try:
        crop_id = crop_cache.get("selected_crop", DEFAULT_CROP)
        crop_info = CROP_DATABASE.get(crop_id, CROP_DATABASE[DEFAULT_CROP])
        
        # Get enhanced sensor data
        enhanced_sensors = {}
        for sensor_id, sensor_data in sensors_cache.items():
            enhanced_sensors[sensor_id] = {
                **sensor_data,
                "moisture_status": get_crop_status(sensor_data["moisture"], crop_info["optimal_moisture"], "moisture"),
                "temp_status": get_crop_status(sensor_data["temperature"], crop_info["optimal_temperature"], "temperature"),
                "humidity_status": get_crop_status(sensor_data["humidity"], crop_info["optimal_humidity"], "humidity")
            }
        
        message = {
            "type": "sensor_update",
            "sensors": enhanced_sensors,
            "timestamp": get_ist_time().isoformat()
        }
        
        await manager.broadcast(json.dumps(message))
    except Exception as e:
        print(f"WebSocket broadcast error: {e}")

# Enhanced data cache with multiple sensors
sensors_cache = {
    "sensor_1": {
        "name": "North Field", 
        "moisture": 59, 
        "temperature": 21, 
        "humidity": 56,
        "location": {"x": 0, "y": 0},
        "battery": 85,
        "last_update": get_ist_time().isoformat()
    },
    "sensor_2": {
        "name": "South Field",
        "moisture": 42,
        "temperature": 28, 
        "humidity": 48,
        "location": {"x": 4, "y": 4},
        "battery": 60,
        "last_update": get_ist_time().isoformat()
    }
}

# Keep crop selection separate
crop_cache = {
    "selected_crop": DEFAULT_CROP
}

# Language cache
language_cache = {
    "current_language": DEFAULT_LANGUAGE
}

def get_translation(key, language_code=None):
    """Get translation for a key in specified language"""
    lang_code = language_code or language_cache.get("current_language", DEFAULT_LANGUAGE)
    lang_data = LANGUAGES.get(lang_code, LANGUAGES[DEFAULT_LANGUAGE])['data']
    return lang_data.get(key, key)  # Return key itself if translation missing

def get_crop_status(sensor_value, optimal_range, sensor_type):
    """Determine status based on crop-specific optimal ranges"""
    if optimal_range["min"] <= sensor_value <= optimal_range["max"]:
        return "OPTIMAL"
    elif sensor_value < optimal_range["min"]:
        return "LOW" if sensor_type != "temperature" else "COLD"
    else:
        return "HIGH" if sensor_type != "temperature" else "HOT"

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    crop = crop_cache.get("selected_crop", DEFAULT_CROP)
    crop_info = CROP_DATABASE.get(crop, CROP_DATABASE[DEFAULT_CROP])
    current_lang = language_cache.get("current_language", DEFAULT_LANGUAGE)
    
    first_sensor = list(sensors_cache.values())[0] if sensors_cache else {
        "moisture": 0, "temperature": 0, "humidity": 0
    }
    
    context = {
        "request": request,
        "moisture_pct": first_sensor["moisture"],
        "soil_temp": f"{first_sensor['temperature']}°C",
        "humidity": first_sensor["humidity"],
        "selected_crop": crop_info["name"],
        "moisture_status": get_crop_status(first_sensor["moisture"], crop_info["optimal_moisture"], "moisture"),
        "temp_status": get_crop_status(first_sensor["temperature"], crop_info["optimal_temperature"], "temperature"),
        "humidity_status": get_crop_status(first_sensor["humidity"], crop_info["optimal_humidity"], "humidity"),
        "crop_water_req": crop_info["water_requirement"],
        "crop_season": crop_info["season"],
        "sensors_count": len(sensors_cache),
        "current_language": current_lang,
        "languages": LANGUAGES,
        "t": lambda key: get_translation(key, current_lang)
    }
    return templates.TemplateResponse("index.html", context)

@router.get("/about", response_class=HTMLResponse)
async def about(request: Request):
    current_lang = language_cache.get("current_language", DEFAULT_LANGUAGE)
    context = {
        "request": request,
        "current_language": current_lang,
        "languages": LANGUAGES,
        "t": lambda key: get_translation(key, current_lang)
    }
    return templates.TemplateResponse("about.html", context)

@router.get("/contact", response_class=HTMLResponse)
async def contact(request: Request):
    current_lang = language_cache.get("current_language", DEFAULT_LANGUAGE)
    context = {
        "request": request,
        "current_language": current_lang,
        "languages": LANGUAGES,
        "t": lambda key: get_translation(key, current_lang)
    }
    return templates.TemplateResponse("contact.html", context)

@router.get("/guide", response_class=HTMLResponse)
async def guide(request: Request):
    current_lang = language_cache.get("current_language", DEFAULT_LANGUAGE)
    context = {
        "request": request,
        "current_language": current_lang,
        "languages": LANGUAGES,
        "t": lambda key: get_translation(key, current_lang)
    }
    return templates.TemplateResponse("guide.html", context)

@router.get("/analytics", response_class=HTMLResponse)
async def analytics(request: Request):
    current_lang = language_cache.get("current_language", DEFAULT_LANGUAGE)
    context = {
        "request": request,
        "current_language": current_lang,
        "languages": LANGUAGES,
        "t": lambda key: get_translation(key, current_lang)
    }
    return templates.TemplateResponse("analytics.html", context)

@router.get("/presentation", response_class=HTMLResponse)
async def presentation(request: Request):
    current_lang = language_cache.get("current_language", DEFAULT_LANGUAGE)
    context = {
        "request": request,
        "current_language": current_lang,
        "languages": LANGUAGES,
        "t": lambda key: get_translation(key, current_lang)
    }
    return templates.TemplateResponse("presentation.html", context)

# Crop selection page
@router.get("/crops", response_class=HTMLResponse)
async def crop_selection(request: Request):
    current_lang = language_cache.get("current_language", DEFAULT_LANGUAGE)
    context = {
        "request": request,
        "crops": CROP_DATABASE,
        "selected_crop": crop_cache.get("selected_crop", DEFAULT_CROP),
        "current_language": current_lang,
        "languages": LANGUAGES,
        "t": lambda key: get_translation(key, current_lang)
    }
    return templates.TemplateResponse("crops.html", context)

# NEW: Multiple sensor API endpoints
@router.get("/api/sensors")
async def get_all_sensors():
    crop_id = crop_cache.get("selected_crop", DEFAULT_CROP)
    crop_info = CROP_DATABASE.get(crop_id, CROP_DATABASE[DEFAULT_CROP])
    
    # Add crop-specific status to each sensor
    enhanced_sensors = {}
    for sensor_id, sensor_data in sensors_cache.items():
        enhanced_sensors[sensor_id] = {
            **sensor_data,
            "moisture_status": get_crop_status(sensor_data["moisture"], crop_info["optimal_moisture"], "moisture"),
            "temp_status": get_crop_status(sensor_data["temperature"], crop_info["optimal_temperature"], "temperature"),
            "humidity_status": get_crop_status(sensor_data["humidity"], crop_info["optimal_humidity"], "humidity")
        }
    
    return JSONResponse(enhanced_sensors)

@router.post("/api/sensor/{sensor_id}")
async def receive_sensor_data(sensor_id: str, request: Request):
    data = await request.json()
    
    if sensor_id not in sensors_cache:
        sensors_cache[sensor_id] = {"name": f"Sensor {sensor_id}"}
    
    sensors_cache[sensor_id].update(data)
    sensors_cache[sensor_id]["last_update"] = get_ist_time().isoformat()
    
    # Broadcast update to all connected clients
    asyncio.create_task(broadcast_sensor_update())
    
    return {"status": "ok", "sensor_id": sensor_id}

# Keep old endpoints for backward compatibility
@router.post("/api/data")
async def receive_data(request: Request):
    data = await request.json()
    # Update first sensor for backward compatibility
    if sensors_cache:
        first_sensor_id = list(sensors_cache.keys())[0]
        sensors_cache[first_sensor_id].update(data)
    
    # Broadcast update to all connected clients
    asyncio.create_task(broadcast_sensor_update())
    
    return {"status": "ok"}

@router.get("/api/data")
async def get_data():
    # For backward compatibility, return first sensor data
    first_sensor = list(sensors_cache.values())[0] if sensors_cache else {
        "moisture": 0, "temperature": 0, "humidity": 0
    }
    
    crop_id = crop_cache.get("selected_crop", DEFAULT_CROP)
    crop_info = CROP_DATABASE.get(crop_id, CROP_DATABASE[DEFAULT_CROP])
    
    response_data = {
        **first_sensor,
        "selected_crop": crop_id,
        "crop_info": crop_info
    }
    return JSONResponse(response_data)

# Crop selection API endpoint
@router.post("/api/select-crop")
async def select_crop(request: Request):
    data = await request.json()
    crop_id = data.get("crop_id", DEFAULT_CROP)
    
    if crop_id in CROP_DATABASE:
        crop_cache["selected_crop"] = crop_id
        
        # Broadcast update since crop change affects status calculations
        asyncio.create_task(broadcast_sensor_update())
        
        return {"status": "success", "selected_crop": crop_id}
    else:
        return {"status": "error", "message": "Crop not found"}

# Get current crop info
@router.get("/api/current-crop")
async def get_current_crop():
    crop_id = crop_cache.get("selected_crop", DEFAULT_CROP)
    crop_info = CROP_DATABASE.get(crop_id, CROP_DATABASE[DEFAULT_CROP])
    return {
        "crop_id": crop_id,
        "crop_info": crop_info
    }

@router.get("/api/field-map")
async def get_field_map():
    crop_id = crop_cache.get("selected_crop", DEFAULT_CROP)
    crop_info = CROP_DATABASE.get(crop_id, CROP_DATABASE[DEFAULT_CROP])
    
    # Generate field map using AI
    field_map = ai_service.generate_field_map(sensors_cache, crop_info)
    recommendations = ai_service.generate_recommendations(field_map, sensors_cache, crop_info)
    health_score = ai_service.get_field_health_score(field_map, crop_info)
    
    return {
        "field_grid": field_map,
        "recommendations": recommendations,
        "health_score": health_score,
        "sensor_count": len(sensors_cache),
        "crop_info": crop_info,
        "generated_at": get_ist_time().isoformat()
    }

@router.get("/api/field-health")
async def get_field_health():
    crop_id = crop_cache.get("selected_crop", DEFAULT_CROP)
    crop_info = CROP_DATABASE.get(crop_id, CROP_DATABASE[DEFAULT_CROP])
    
    field_map = ai_service.generate_field_map(sensors_cache, crop_info)
    health_score = ai_service.get_field_health_score(field_map, crop_info)
    
    return {
        "health_score": health_score,
        "crop": crop_info["name"],
        "optimal_range": f"{crop_info['optimal_moisture']['min']}-{crop_info['optimal_moisture']['max']}%"
    }

@router.get("/api/weather")
async def get_weather():
    """Get weather forecast for farm"""
    weather_data = weather_service.get_weather_forecast()
    return JSONResponse(weather_data)

@router.get("/api/system-status")
async def get_system_status():
    """Get overall system health and status"""
    crop_id = crop_cache.get("selected_crop", DEFAULT_CROP)
    crop_info = CROP_DATABASE.get(crop_id, CROP_DATABASE[DEFAULT_CROP])
    
    # Calculate system health
    active_sensors = len(sensors_cache)
    total_battery = sum(sensor.get('battery', 0) for sensor in sensors_cache.values()) / max(active_sensors, 1)
    
    # Check if any sensors need attention
    critical_sensors = []
    for sensor_id, sensor_data in sensors_cache.items():
        if sensor_data.get('battery', 100) < 20:
            critical_sensors.append(f"{sensor_data['name']} (low battery)")
    
    return {
        "status": "healthy" if active_sensors > 0 and total_battery > 30 else "needs_attention",
        "active_sensors": active_sensors,
        "avg_battery": round(total_battery),
        "critical_alerts": critical_sensors,
        "crop_monitoring": crop_info["name"],
        "last_data_update": max([sensor.get('last_update', '') for sensor in sensors_cache.values()], default=''),
        "websocket_connections": len(manager.active_connections) if manager else 0
    }

@router.get("/api/export-data")
async def export_sensor_data():
    """Export sensor data as JSON for analysis"""
    export_data = {
        "exported_at": get_ist_time().isoformat(),
        "crop_selected": crop_cache.get("selected_crop", DEFAULT_CROP),
        "sensors": sensors_cache,
        "crop_database": CROP_DATABASE
    }
    
    return JSONResponse(
        content=export_data,
        media_type="application/json",
        headers={"Content-Disposition": "attachment; filename=sensor_data_export.json"}
    )

@router.get("/api/demo-mode")
async def toggle_demo_mode():
    """Toggle demo mode for competition presentation"""
    global sensors_cache
    
    # Toggle between demo data and real data
    if sensors_cache["sensor_1"]["moisture"] == 59:  # Real data
        sensors_cache = {
            "sensor_1": {
                "name": "North Field", 
                "moisture": 25,  # Critical - for demo
                "temperature": 35, 
                "humidity": 30,
                "location": {"x": 0, "y": 0},
                "battery": 15,  # Low battery for demo
                "last_update": get_ist_time().isoformat()
            },
            "sensor_2": {
                "name": "South Field",
                "moisture": 75,  # Overwatered for demo
                "temperature": 18, 
                "humidity": 85,
                "location": {"x": 4, "y": 4},
                "battery": 90,
                "last_update": get_ist_time().isoformat()
            }
        }
        mode = "demo"
    else:
        # Reset to normal data
        sensors_cache = {
            "sensor_1": {
                "name": "North Field", 
                "moisture": 59, 
                "temperature": 21, 
                "humidity": 56,
                "location": {"x": 0, "y": 0},
                "battery": 85,
                "last_update": get_ist_time().isoformat()
            },
            "sensor_2": {
                "name": "South Field",
                "moisture": 42,
                "temperature": 28, 
                "humidity": 48,
                "location": {"x": 4, "y": 4},
                "battery": 60,
                "last_update": get_ist_time().isoformat()
            }
        }
        mode = "normal"
    
    asyncio.create_task(broadcast_sensor_update())
    return {"status": "success", "mode": mode}

@router.get("/api/predict-yield")
async def predict_yield():
    """Predict crop yield using ML model"""
    crop_id = crop_cache.get("selected_crop", DEFAULT_CROP)
    crop_info = CROP_DATABASE.get(crop_id, CROP_DATABASE[DEFAULT_CROP])
    
    # Get current field data for prediction
    field_map = ai_service.generate_field_map(sensors_cache, crop_info)
    health_score = ai_service.get_field_health_score(field_map, crop_info)
    
    # Calculate averages from sensors
    avg_moisture = sum(sensor['moisture'] for sensor in sensors_cache.values()) / len(sensors_cache)
    avg_temperature = sum(sensor['temperature'] for sensor in sensors_cache.values()) / len(sensors_cache)
    
    # Get prediction
    prediction = ml_service.predict_yield(
        crop_type=crop_id,
        field_health_score=health_score,
        avg_moisture=avg_moisture,
        avg_temperature=avg_temperature
    )
    
    return {
        "crop": crop_info["name"],
        "prediction": prediction,
        "input_data": {
            "health_score": health_score,
            "avg_moisture": round(avg_moisture, 1),
            "avg_temperature": round(avg_temperature, 1)
        }
    }

@router.get("/api/harvest-prediction")
async def predict_harvest():
    """Predict harvest readiness"""
    crop_id = crop_cache.get("selected_crop", DEFAULT_CROP)
    crop_info = CROP_DATABASE.get(crop_id, CROP_DATABASE[DEFAULT_CROP])
    
    # For demo, use a planting date 60 days ago
    planting_date = (datetime.now() - timedelta(days=60)).isoformat()
    
    prediction = ml_service.predict_harvest_readiness(crop_id, planting_date)
    
    return {
        "crop": crop_info["name"],
        "harvest_prediction": prediction,
        "planting_date": planting_date
    }

# Language switch endpoint
@router.post("/api/change-language")
async def change_language(request: Request):
    data = await request.json()
    language_code = data.get("language_code", DEFAULT_LANGUAGE)
    
    if language_code in LANGUAGES:
        language_cache["current_language"] = language_code
        
        # Broadcast language change to all connected clients
        if manager:
            message = {
                "type": "language_changed",
                "language": language_code
            }
            await manager.broadcast(json.dumps(message))
        
        return {"status": "success", "language": language_code}
    else:
        return {"status": "error", "message": "Language not supported"}

@router.get("/api/current-language")
async def get_current_language():
    """Get current language setting"""
    return {
        "current_language": language_cache.get("current_language", DEFAULT_LANGUAGE),
        "available_languages": list(LANGUAGES.keys())
    }

# Error page
@router.get("/error", response_class=HTMLResponse)
async def error_page(request: Request):
    current_lang = language_cache.get("current_language", DEFAULT_LANGUAGE)
    context = {
        "request": request,
        "current_language": current_lang,
        "languages": LANGUAGES,
        "t": lambda key: get_translation(key, current_lang)
    }
    return templates.TemplateResponse("error.html", context)