import requests
import os
from datetime import datetime, timedelta
import pytz

class WeatherService:
    def __init__(self):
        self.api_key = "your_openweather_api_key"  # Free tier available
        self.base_url = "http://api.openweathermap.org/data/2.5"
        
    def get_weather_forecast(self, lat=20.5937, lng=78.9629):  # Default: Central India
        """Get weather forecast for farm location"""
        try:
            # For demo, use mock data to avoid API key setup
            return self.get_mock_weather_data()
            
        except Exception as e:
            print(f"Weather API error: {e}")
            return self.get_mock_weather_data()
    
    def get_mock_weather_data(self):
        """Mock weather data for demo - perfect for competition!"""
        ist = pytz.timezone('Asia/Kolkata')
        now = datetime.now(ist)
        
        return {
            "location": "Farm Field (Demo)",
            "current": {
                "temperature": 28,
                "humidity": 65,
                "description": "Partly Cloudy",
                "rain_probability": 20,
                "wind_speed": 12,
                "timestamp": now.isoformat(),
                "icon": "⛅"  # Theme-appropriate icon
            },
            "forecast": [
                {
                    "day": "Today",
                    "high_temp": 32,
                    "low_temp": 22,
                    "rain_probability": 20,
                    "description": "Partly Cloudy",
                    "icon": "⛅"
                },
                {
                    "day": "Tomorrow", 
                    "high_temp": 34,
                    "low_temp": 24,
                    "rain_probability": 60,
                    "description": "Rain Expected",
                    "icon": "🌧️"
                },
                {
                    "day": "Day after",
                    "high_temp": 30,
                    "low_temp": 23,
                    "rain_probability": 80,
                    "description": "Heavy Rain",
                    "icon": "⛈️"
                }
            ],
            "alerts": ["Heavy rain expected tomorrow - delay irrigation"]
        }

# Global instance
weather_service = WeatherService()